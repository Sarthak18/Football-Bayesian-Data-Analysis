import csv
import pandas as pd
import  numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
filepath = 'C:/Users/srthk/PycharmProjects/Bayesian/results.csv'
data = pd.read_csv(filepath)
years = data['date'].map(lambda y: int(str(y)[:4]))  ## only year without month and days (type integer)
friendly_match = data['tournament'].map(lambda y: 1 if y=='Friendly' else 0 )
YEARS = list(np.unique(years))                       ## unique years
COUNTRY = list(np.unique(data['country']))           ## unique country

goalAll = pd.DataFrame(data['home_score']+data['away_score'])  ## how many goals were scored in one match by both teams
goalAll.insert(1, 'Date', years)                         ## creates a new data table (new DataFrame) (add column with year when this match was played)
goalAll.insert(2, 'Country', data['country'])            ## add column with name of country in which was a match
goalAll.insert(3, 'Tournament', data['tournament'])      ## type of match
goalAll.insert(4, 'Friendly', friendly_match)
goalAll.columns = ['Goals','Year','Country', 'Tournament', 'Friendly']
print(goalAll.to_csv(r'Bayesian.txt', header=None, index=None, sep=' ', mode='a'))

