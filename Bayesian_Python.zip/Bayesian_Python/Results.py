import csv
import pandas as pd
import  numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
filepath = 'C:/Users/srthk/PycharmProjects/Bayesian/results.csv'
dataset = pd.read_csv(filepath)
years = dataset['date'].map(lambda y: int(str(y)[:4]))
month = dataset['date'].map(lambda y: int(str(y)[5:7]))
day =  dataset['date'].map(lambda y: int(str(y)[8:11]))
dataset['Results']= dataset['home_score'] - dataset['away_score']
print(month)
