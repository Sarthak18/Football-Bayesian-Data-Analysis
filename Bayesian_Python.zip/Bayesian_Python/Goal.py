import csv
import pandas as pd
import  numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

filepath = 'C:/Users/srthk/PycharmProjects/Bayesian/results.csv'
data = pd.read_csv(filepath)
sum_goals = []
for year in YEARS:
    sum_goals.append(goalAll[goalAll['Year']==year]['Goals'].sum())